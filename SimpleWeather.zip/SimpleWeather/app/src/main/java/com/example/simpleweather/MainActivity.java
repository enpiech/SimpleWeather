package com.example.simpleweather;

import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import com.example.simpleweather.data.model.WeatherResponse;
import com.example.simpleweather.data.remote.WeatherService;
import com.example.simpleweather.helper.WeatherUtils;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private WeatherService mService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mService = WeatherUtils.getWeatherData();
        loadWeather();
    }

    void loadWeather() {
        mService.getWeatherByCityId("1566083","45a87f9aadf5fddecd27d0d1a5da8ba8").enqueue(
                new Callback<WeatherResponse>() {
                    @Override
                    public void onResponse(final Call<WeatherResponse> call,
                            final Response<WeatherResponse> response) {
                        if (response.isSuccessful()) {
                            Log.d("Weather", response.body().toString());
                        }
                    }

                    @Override
                    public void onFailure(final Call<WeatherResponse> call, final Throwable t) {
                        Log.d("WeatherAPI", "error loading from API");
                    }
                });
    }
}
