package com.example.simpleweather.helper;

import com.example.simpleweather.data.remote.APIClient;
import com.example.simpleweather.data.remote.WeatherService;

public class WeatherUtils {
    private static final String BASE_URL = "http://api.openweathermap.org/";
    private static final String APP_ID = "45a87f9aadf5fddecd27d0d1a5da8ba8";
    private static final String lat = "35";
    private static final String lon = "139";

    public static WeatherService getWeatherData() {
        return APIClient.getClient(BASE_URL).create(WeatherService.class);
    }
}
