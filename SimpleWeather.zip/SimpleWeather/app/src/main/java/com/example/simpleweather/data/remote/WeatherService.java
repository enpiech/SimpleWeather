package com.example.simpleweather.data.remote;

import com.example.simpleweather.data.model.WeatherResponse;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface WeatherService {
    @GET("/data/2.5/weather?")
    Call<WeatherResponse> getWeatherByCityName(@Query("q") String cityName);

    @GET("/data/2.5/weather?")
    Call<WeatherResponse> getCurrentWeatherData(@Query("lat") String lat, @Query("lon") String lon, @Query("APPID") String app_id);

    @GET("/data/2.5/weather?")
    Call<WeatherResponse> getWeatherByCityId(@Query("id") String cityId, @Query("APPID") String app_id);

}
