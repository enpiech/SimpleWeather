package com.example.simpleweather.data.listener;

public interface WeatherItemListener {
    void onWeatherItemClick(int id);
}
